<?php 
//                         V----------------Edit Here To Change Password 
if (@$_GET['password'] == 123456) {
//                         V---------------- The Hidden Channel List
?>http://mykodi.co.uk/xstream/all.m3u<?php 
// else Conditional region1
} else { ?><?php } 
// endif Conditional region1
?>