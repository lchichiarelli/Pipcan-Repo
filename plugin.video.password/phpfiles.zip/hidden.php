<?php 
//                         V----------------Edit Here To Change Password 
if (@$_GET['password'] == 123456) {
?>correct<?php 
// else Conditional region1
} else { ?>Wrong<?php } 
// endif Conditional region1
?>